package kgfbank;

public interface MaintenanceCharge {
	public float calculateMaintenanceCharge(float noOfYears);
}
