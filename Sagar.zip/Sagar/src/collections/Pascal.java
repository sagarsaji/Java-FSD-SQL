package collections;

import java.util.Scanner;

public class Pascal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lim;
		ArrayList<>
		Scanner n = new Scanner(System.in);
		System.out.println("Enter limit of triangle : ");
		lim = n.nextInt();
		for(int i=0;i<lim;i++) {
			
		}
	}

}
