package interfaces;

/**
 * @author Administrator
 *
 */
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Newinterface j = new jio();
		j.calling();
		j.dialling();
	}

}
