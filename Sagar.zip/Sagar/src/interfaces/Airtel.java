package interfaces;

public class Airtel implements Newinterface {
	public void calling() {
		System.out.println("This is airtel calling");
	}
	
	public void dialling() {
		System.out.println("This is airtel dialling");
	}
}
