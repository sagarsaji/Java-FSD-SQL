package interfaces;

public interface Newinterface {
	public void calling();
	public void dialling();
}
