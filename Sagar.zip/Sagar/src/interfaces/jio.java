package interfaces;

public class jio implements Newinterface {
	public void calling() {
		System.out.println("this is jio calling");
	}
	
	public void dialling() {
		System.out.println("this is jio dialling");
	}
}
